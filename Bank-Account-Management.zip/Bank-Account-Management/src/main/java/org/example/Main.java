package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Account acc=new Account("Bha123", 50000.0);

        acc.deposit(1500);
        acc.withdraw(2000);
        acc.withdraw(6000); // will fail

        System.out.println("\nCurrent Balance: " + acc.getData());
        System.out.println();
        System.out.println("Transaction history below:");


        acc.viewTransaction();

    }
}