package org.example;

import java.util.ArrayList;
import java.util.List;

public class Account {

    private String accNum;
    private Double balance;
    private List<String> transHistory;

    public  Account(String acNum, Double initialAmt){
        this.accNum = accNum;
        this.balance = initialAmt;
        this.transHistory = new ArrayList<>();
        transHistory.add("Account created with balance: " + initialAmt);

    }

    public void deposit(double blc){
        if(blc>0){

            balance=balance+blc;
            transHistory.add("Balace deposited: "+blc+"  and Updtaed Balance is: "+balance);
            System.out.println("Deposite SuccessFull..");

        }
        else {
            System.out.println("Invalid Amount..");
        }
    }
    public void withdraw(double amt){

        if(amt<balance){

            balance=balance-amt;
            transHistory.add("Balace withdraw: "+amt+"  and Updtaed Balance is: "+balance);
            System.out.println("Withdraw SuccessFull..");

        }
        else {
            System.out.println("Insufficent Bank Balance.. Check Again..!");
        }
    }

    public double getData(){
        return balance;
    }

    public  void viewTransaction(){

        for(String data: transHistory){

            System.out.println(data);
        }

    }


}
