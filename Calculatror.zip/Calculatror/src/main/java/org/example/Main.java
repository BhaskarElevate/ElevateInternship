package org.example;

import java.util.Scanner;

import static org.example.CalculatorM.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        long a;
        long b;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the values for Operation:");

        a=sc.nextLong();
        b=sc.nextLong();

        System.out.println("Enter the option Num from List");

        System.out.println();
        System.out.println("For addition : Enter 1");
        System.out.println("For Substraction: Enter 2");
        System.out.println("For Multiplication : Enter 3");
        System.out.println("For Division : Enter 4");
        int num=sc.nextInt();
        switch(num)
        {
            case 1:testAdd(a, b);break;
            case 2: testSub(a, b);break;
            case 3: testMul(a, b);break;
            case 4: testDiv(a, b);break;

        }
    }

}