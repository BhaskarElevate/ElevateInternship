package org.example;

import java.util.Scanner;

public class CalculatorM {

    static void testDiv(long a, long b) {

        System.out.println("The Division of given Values are: "+(a/b));
    }

    static void testMul(long a, long b) {

        System.out.println("The Multiplication of given Values are: "+(a*b));
    }

    static void testSub(long a, long b) {
        System.out.println("The Substraction of given Values are: "+(a-b));
    }

    static void testAdd(long a, long b) {
        System.out.println("The Addition of given Values are: "+(a+b));
    }

}
